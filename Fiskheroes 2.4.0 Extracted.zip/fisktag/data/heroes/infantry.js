function init(hero) {
    hero.setName("class.fisktag.infantry.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addPowers("fisktag:infantry");
    hero.addAttribute("FISKTAG_HEALTH", 3, 0);
    hero.addAttribute("FALL_RESISTANCE", 10.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBindFunc("func_ARMOR", armorKey, "key.toggleArmor", 2);

    hero.addAttributeProfile("ARMOR", armorProfile);
    hero.setAttributeProfile(getAttributeProfile);
    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
    hero.supplyFunction("fisktag:getAbilities", {
        "abilities": [
            {
                "input": "func_ARMOR",
                "toggleData": "entity.getData('fisktag:dyn/armor') > 0",
                "enabledData": "entity.getData('fisktag:dyn/armor') > -1 && !entity.isInvulnerable()"
            }
        ]
    });

    hero.setTickHandler((entity, manager) => {
        if (entity.isInvulnerable()) {
            manager.setData(entity, "fisktag:dyn/armor", 0);
            manager.setData(entity, "fisktag:dyn/armor_timer", 0);
            return;
        }
        var armor = entity.getData("fisktag:dyn/armor");
        if ((armor > 0 || entity.getData("fisktag:dyn/armor_timer") > 0) && entity.getData("fiskheroes:time_since_damaged") < 4) {
            manager.setData(entity, "fisktag:dyn/armor", -1);
            if (armor > 0) {
                entity.playSound("fisktag:class.infantry.armor.break", 1, 1.1 - Math.random() * 0.3);
                entity.playSound("fisktag:class.infantry.armor.disable", 0.7, 1);
            }
        }
        manager.incrementData(entity, "fisktag:dyn/armor_timer", 20, 8, armor == 1);
    });
}

function armorKey(player, manager) {
    if (player.isInvulnerable()) {
        return false;
    }
    var armor = player.getData("fisktag:dyn/armor");
    if (armor == -1) {
        return false;
    }
    manager.setData(player, "fisktag:dyn/armor", armor == 0 ? 1 : 0);
    player.playSound("fisktag:class.infantry.armor." + (armor == 0 ? "enable" : "disable"), 0.7, 1);
    return true;
}

function armorProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FISKTAG_ARMOR", 1, 0);
}

function getAttributeProfile(entity) {
    return entity.getData("fisktag:dyn/armor") != 0 || entity.getData("fisktag:dyn/armor_timer") > 0 ? "ARMOR" : null;
}

function isModifierEnabled(entity, modifier) {
    return entity.getData("fisktag:dyn/armor") > 0 || entity.getData("fisktag:dyn/armor_timer") > 0;
}
