function init(hero) {
    hero.setName("class.fisktag.demolitionist.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addPowers("fisktag:demolitionist");
    hero.addAttribute("FISKTAG_HEALTH", 3, 0);
    hero.addAttribute("FALL_RESISTANCE", 10.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
    hero.supplyFunction("fisktagScroll", entity => true);
    hero.supplyFunction("fisktag:getAbilities", {
        "abilities": [
            {
                "input": {
                    "key": "key.use",
                    "name": "key.grenade",
                    "isVisible": "entity.getHeldItem().isEmpty()"
                },
                "cooldownData": {
                    "equipment": "fiskheroes:grenade"
                }
            }
        ]
    });
    
    hero.setTickHandler((entity, manager) => {
        if (entity.getHeldItem().isEmpty()) {
            manager.setData(entity, "fiskheroes:utility_belt_type", 0);
        }
        else {
            manager.setData(entity, "fiskheroes:prev_utility_belt_type", 0);
            manager.setData(entity, "fiskheroes:utility_belt_type", -1);
        }
    });
}
