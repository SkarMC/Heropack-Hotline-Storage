function init(hero) {
    hero.setName("class.fisktag.assassin.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.hood");

    hero.addPowers("fisktag:assassin");
    hero.addAttribute("FISKTAG_HEALTH", 3, 0);
    hero.addAttribute("FALL_RESISTANCE", 10.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.addAttributeProfile("BLADE", bladeProfile);
    hero.setAttributeProfile(getProfile);
    hero.setDamageProfile(getProfile);
    hero.addDamageProfile("BLADE", {"types": {"SHARP": 1.0}});
    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
    hero.supplyFunction("fisktagScroll", true);

	hero.addSoundEvent("PUNCH", "fisktag:assassin_slash");

    hero.setTickHandler((entity, manager) => {
        manager.setData(entity, "fiskheroes:blade", entity.getHeldItem().isEmpty());
    });
}

function bladeProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FISKTAG_ARMOR", -2, 0);
    profile.addAttribute("PUNCH_DAMAGE", 42069.0, 0);
}

function getProfile(entity) {
    return entity.getData("fiskheroes:blade") && entity.isAlive() ? "BLADE" : null;
}
