function init(hero) {
    hero.setName("class.fisktag.scout.name");
    hero.setTier(1);
    hero.hide();

    hero.setHelmet("item.superhero_armor.piece.helmet");

    hero.addPowers("fisktag:scout");
    hero.addAttribute("FISKTAG_HEALTH", 2, 0);
    hero.addAttribute("FALL_RESISTANCE", 1.0, 1);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.5, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setHasPermission((entity, permission) => permission === "USE_FISKTAG_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() === "fisktag:weapon");
    hero.supplyFunction("fisktag:getAbilities", {
        "abilities": [
            {
                "input": {
                    "key": "key.jump",
                    "name": "key.rocketLeap"
                },
                "cooldownData": "fisktag:dyn/leap_cooldown"
            }
        ]
    });

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskheroes:flying")) {
            manager.setInterpolatedData(entity, "fisktag:dyn/leap_cooldown", 1);
        }
        manager.incrementData(entity, "fisktag:dyn/leap_cooldown", 40, false);
    });
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
        case "fiskheroes:controlled_flight":
            return entity.isSprinting() && entity.getData("fisktag:dyn/leap_cooldown") == 0;
        default:
            return false;
    }
}
