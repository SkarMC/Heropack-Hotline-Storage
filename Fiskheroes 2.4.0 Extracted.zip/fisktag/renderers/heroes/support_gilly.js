extend("fisktag:support");
loadTextures({
    "base": "fisktag:gilly/support",
    "lights": "fisktag:gilly/support_lights",
    "lights_red": "fisktag:gilly/support_lights_red",
    "lights_blue": "fisktag:gilly/support_lights_blue"
});
