extend("fisktag:demolitionist");
loadTextures({
    "base": "fisktag:gilly/demolitionist",
    "lights": "fisktag:gilly/demolitionist_lights",
    "lights_red": "fisktag:gilly/demolitionist_lights_red",
    "lights_blue": "fisktag:gilly/demolitionist_lights_blue"
});
