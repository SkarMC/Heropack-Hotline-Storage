extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:gilly/assassin",
    "lights": "fisktag:gilly/assassin_lights",
    "lights_red": "fisktag:gilly/assassin_lights_red",
    "lights_blue": "fisktag:gilly/assassin_lights_blue",
    "blade": "fisktag:gilly/assassin_blade",
    "blade_red": "fisktag:gilly/assassin_blade_lights_red",
    "blade_blue": "fisktag:gilly/assassin_blade_lights_blue",
    "blade_neutral": "fisktag:gilly/assassin_blade_lights",
    "cape": "fisktag:gilly/assassin_cape",
    "cape_neutral": "fisktag:gilly/assassin_cape_lights",
    "cape_red": "fisktag:gilly/assassin_cape_lights_red",
    "cape_blue": "fisktag:gilly/assassin_cape_lights_blue"
});

var capes = implement("fiskheroes:external/capes");

var cape;
var blade;
var blade_model;

function initEffects(renderer) {
    parent.initEffects(renderer);
    
    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.maxFlare = 0.6;
    physics.flareDegree = 1.5;
    physics.restFlare = 0.2;
    cape = capes.createDefault(renderer, 23, "fiskheroes:cape_default.mesh.json", physics);

    blade_model = renderer.createResource("MODEL", "fisktag:assassin_blade_gilly");
    blade = renderer.createEffect("fiskheroes:model");
    blade.setOffset(1, 8, -1).setRotation(0, -90, 0);
    blade.setModel(blade_model);
    blade.anchor.set("rightArm");
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
    addAnimation(renderer, "assassin.blade", "fisktag:blade_pose")
        .setData((entity, data) => {
            data.load(0, entity.getPunchTimerInterpolated());
            data.load(1, 1);
        })
        .setCondition(entity => entity.getData("fiskheroes:blade"))
        .priority = -10;
    renderer.reprioritizeDefaultAnimation("PUNCH", -9);
}

function render(entity, renderLayer, isFirstPersonArm) {
    switch (entity.team().name()) {
        case "fisktag_RED":
            blade_model.texture.set("blade", "blade_red");
            cape.effect.texture.set("cape", "cape_red");
            break;
        case "fisktag_BLUE":
            blade_model.texture.set("blade", "blade_blue");
            cape.effect.texture.set("cape", "cape_blue");
            break;
        default:
            blade_model.texture.set("blade", "blade_neutral");
            cape.effect.texture.set("cape", "cape_neutral");
            break;
    }
    if (entity.getData("fiskheroes:blade")) {
        blade.render();
    }
    if (!isFirstPersonArm) {
        cape.render(entity);
    }
}
