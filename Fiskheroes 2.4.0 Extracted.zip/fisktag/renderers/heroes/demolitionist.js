extend("fisktag:fisktag_base");
loadTextures({
    "base": "fisktag:demolitionist",
    "lights": "fisktag:demolitionist_lights",
    "lights_red": "fisktag:demolitionist_lights_red",
    "lights_blue": "fisktag:demolitionist_lights_blue"
});
