function continuePlaying(entity, sound) {
    var point = sound.context();
    if (point == null || !point.exists()) {
        return false;
    }

    var prog = point.getProgress();
    var volume = sound.volume();
    var range = sound.range();
    var v = (1 + prog) / 2;
    var p = 1;

    if (sound.id() === "fisktag:point.ambient.loop.blue") {
        v = 1 - v;
    }

    if (point.isEmpty() && point.isNeutral() || Math.abs(prog) >= 1) {
        volume += (v * 0.3 - volume) / 20;
        range += (point.getRange() + 8 - range) / 20;
    }
    else {
        volume += (v * 0.6 - volume) / 4;
        range += (point.getRange() + 16 - range) / 4;
        if (Math.abs(prog) < 1) {
            p = Math.pow(2, Math.abs(point.getBalance()) / 12);
        }
    }

    sound.setVolume(volume);
    sound.setPitch(sound.pitch() + (p - sound.pitch()) / 40);
    sound.setRange(range);
    return true;
}
